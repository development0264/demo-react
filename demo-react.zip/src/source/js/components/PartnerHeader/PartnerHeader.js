import React,{ useState } from 'react'
import {
    Collapse,
    Navbar,
    NavbarToggler,
    Nav,
    NavItem,
    Container,
    Row,
    Col
} from 'reactstrap'
import headLogo from '../../../images/icon-cobranding.png'

const PartnerHeader = ({children, hideNavigation=false, partnerData}) => {
    const [isOpen, setIsOpen] = useState(false)

    const toggle = () => setIsOpen(!isOpen)
    const { imageUrl  } = partnerData
    const hideNav = (hideNavigation == true) ? false : true;

    return <Container>
        <Row>
            <Col><div className="landing-header">
                <Navbar color="light" light expand="md">
                    <div className="header-styling" style={{margin: hideNav ? 0 : '0 auto'}}>
                        {
                            imageUrl ? <div className="header-styling-partner">
                                <img src={imageUrl} height="35" />
                                <span> + </span>
                            </div> : null
                        }
                        <img src={headLogo} height="35" />
                    </div>
                    <NavbarToggler onClick={toggle} />
                    {hideNav && <Collapse isOpen={isOpen} navbar>
                        <Nav className="mr-auto" navbar>
                            <NavItem>
                                {children()}
                            </NavItem>
                        </Nav>
                    </Collapse> }
                </Navbar>
            </div>
            </Col>
        </Row>
    </Container>

}

export default PartnerHeader