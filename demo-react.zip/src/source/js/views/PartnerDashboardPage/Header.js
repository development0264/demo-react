import React, { Component } from 'react'
import { Link } from 'react-router-dom'
import { connect } from 'react-redux'

import "../../../styles/home.css"
import "../../../styles/home_responsive.css"
import headLogo from '../../../images/icon-cobranding.png'
import Icon from '@material-ui/core/Icon';
import { SignOut } from '../../actions/authAction';
import { resetPartnerDashData } from "./../../actions/partnerDashboardAction"

class Header extends Component {

    constructor(props) {
        super(props)
        this.state = {
            dropdownOpen: false,
            isMenuShow: false,
            logoImageSrc: '',
            logoImageHash: Date.now()
        }
    }
    componentDidMount() {
        if (this.props.partnerLogo) {
            this.setState({
                logoImageSrc: this.props.partnerLogo,
                logoImageHash: Date.now()
            })
        }
    }
    UNSAFE_componentWillReceiveProps(nextProps) {
        if (nextProps.partnerLogo && nextProps.partnerLogo != '') {
            this.setState({
                logoImageSrc: nextProps.partnerLogo,
                logoImageHash: Date.now()
            })
        }
    }

    signOutUser() {
        this.props.SignOut();
        this.props.resetPartnerDashData();
    }

    toggle = () => {
        this.setState({
            dropdownOpen: !this.state.dropdownOpen
        });
    }
    hideSidebar = () => {
        this.setState({
            isMenuShow: !this.state.isMenuShow
        });
    }
    closeSidebarLink = () => {
        this.setState({ isMenuShow: false });
    }
    render() {
        const { partnerData, agentLogoImage } = this.props;
        const { dropdownOpen, isMenuShow, logoImageSrc, logoImageHash } = this.state;

        return (
            <div className="header_bottom_shadow col p-0">
                <div className="container-fluid">
                    <div className="row">
                        <div className="col">
                            <div className="landing-header">
                                <nav className="navbar navbar-expand-md navbar-light bg-light">
                                    <div className="header-styling" style={{ margin: '0px' }}>
                                        {partnerData && partnerData.logourl && logoImageSrc ? <div className="header-styling-partner">
                                            <img src={`${logoImageSrc}?${logoImageHash}`} height="28" className="header__main__img" />
                                            <span> + </span>
                                        </div> : null}
                                        <img src={headLogo} className="header__main__img" />
                                    </div>
                                    <div className="collapse navbar-collapse">
                                        <ul className="nav nav-pills">
                                            {partnerData && Object.keys(partnerData).length ?
                                                <li className="nav-item dropdown" >
                                                    <div className="nav-link" onClick={() => this.toggle()} role="button"><i class="fas fa-user-circle" style={{ fontSize: '30px' }}></i>{partnerData.firstname} {partnerData.lastname}</div>
                                                    <div className="dropdown-menu" style={{ display: dropdownOpen ? 'block' : 'none' }}>
                                                        <Link className="dropdown-item" onClick={() => this.toggle()} to={"/partner/dashboard/profile"}>Profile</Link>
                                                        <Link className="dropdown-item" onClick={() => this.toggle()} to={"/partner/dashboard/updatepassword"}>Update Password</Link>
                                                        <div className="dropdown-divider"></div>
                                                        <div className="dropdown-item" onClick={() => this.signOutUser()} style={{ cursor: 'pointer' }}>Sign out</div>
                                                    </div>
                                                </li>
                                                : null}
                                        </ul>
                                    </div>
                                    <button type="button" className="navbar-toggler" onClick={this.hideSidebar} style={{ float: 'right' }}>
                                        <span className={`fas ${isMenuShow ? 'fa-times' : 'fa-bars'}`}></span>
                                    </button>
                                </nav>
                                <div className="mobile-menu-navbar">
                                    <div className={`collapse navbar-collapse ${isMenuShow ? 'show' : ''}`} id="navbarCollapse">
                                        {this.props.menuLinks ?
                                            <ul className="navbar-nav mr-auto">{
                                                this.props.menuLinks.map(item => {
                                                    return (<li key={item.label} className={(this.props.menuPath == `/partner/dashboard/${item.link}`) ? 'nav-item dashboard_link active' : 'nav-item dashboard_link'}>
                                                        <Link className="nav-link" onClick={this.closeSidebarLink} to={`/partner/dashboard/${item.link}`}><Icon>{item.icon}</Icon> {item.label}</Link>
                                                    </li>)
                                                })
                                            }
                                                <li className={(this.props.menuPath == '/partner/dashboard/profile') ? 'nav-item dashboard_link active' : 'nav-item dashboard_link'} >
                                                    <Link className="nav-link" onClick={this.closeSidebarLink} to={"/partner/dashboard/profile"}><Icon>{'person'}</Icon> Profile</Link>
                                                </li>
                                                <li className={(this.props.menuPath == '/partner/dashboard/updatepassword') ? 'nav-item dashboard_link active' : 'nav-item dashboard_link'}>
                                                    <Link className="nav-link" onClick={this.closeSidebarLink} to={"/partner/dashboard/updatepassword"}><Icon>{'lock'}</Icon> Update Password</Link>
                                                </li>
                                            </ul>
                                            : null}
                                        <div className="navbar-nav ml-auto">
                                            <div className="nav-item nav-link" onClick={() => this.signOutUser()} style={{ cursor: 'pointer', color: '#ffffff', marginBottom: '10px' }}><Icon>{'close'}</Icon> Sign out</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = state => {
    const { userTokenId, isUserLogin } = state.authReducer;
    const { agentData, agentLogoImage } = state.agentReducer;
    const { partnerData, partnerLogo } = state.partnerDashboardReducer;

    return { userTokenId, isUserLogin, agentData, agentLogoImage, partnerData, partnerLogo };
}

export default connect(mapStateToProps, { SignOut, resetPartnerDashData })(Header);
