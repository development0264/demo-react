import React, { Component } from 'react'
import { connect } from 'react-redux'
import ReactLoading from 'react-loading'
import { Container, Row, Col, Input, Alert, FormGroup, Label, Button } from 'reactstrap';
import Header from './Header'
import PopUpModal from './PopUpModal'
import { inputValidator } from '../../utils/helpers';
import { Redirect } from 'react-router'
import { authenticateUser, loginUser } from '../../actions/authAction';
import { resetAgentData } from '../../actions/agentAction';
import { Link } from "react-router-dom"

import "../../../styles/Agents/login.css"
import CommonInput from '../../components/CommonInput/CommonInput';
const errorMsgs = {
    "email": "Please enter a valid email address",
    "password": "Please enter a valid password",
}

class PartnerDashboardLogin extends Component {
    constructor(props) {
        super(props)
        this.state = {
            fields: {
                "email": "",
                "password": ""
            },
            errors: {},
            warnings: {},
            isUserLogin: true,
            userTokenId: '',
            userInfo: {},
            loginErrorPopup: false,
            visibleAlert: false,
            showPassword: false,
        }
        this.loginSubmit = this.loginSubmit.bind(this)
    }
    componentDidMount() {
        // this.props.resetAgentData();
        if (this.props.passwordUpdateMsg != '') {
            this.setState({ visibleAlert: true });
        }
    }
    handleChange(field, e) {
        let fields = this.state.fields;
        fields[field] = e.target.value.trim();
        this.setState({ fields }, () => {
            this.handleValidation(field)
        });
    }
    handleValidation(type) {
        let fields = this.state.fields;
        let errors = this.state.errors;
        let warnings = this.state.warnings;
        let formIsValid = true;
        if (!inputValidator(fields[type], type)) {
            this.setState({ errors: { ...errors, [type]: '' }, warnings: { ...warnings, [type]: '' } });
        }
        else {
            if (errors.hasOwnProperty(type)) {
                delete errors[type];
                this.setState({ errors: { ...errors } });
            }
        }
    }
    validateAll() {
        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;
        Object.keys(fields).map((type, index) => {
            if (!inputValidator(fields[type], type)) {
                formIsValid = false;
                errors[type] = errorMsgs[type] ? errorMsgs[type] : "Field is invilad";
            }
        })
        this.setState({ errors })
        return formIsValid;
    }
    UNSAFE_componentWillReceiveProps(nextProps) {
        if (nextProps.isUserLogin == true && nextProps.userTokenId != '') {
            this.setState({ isUserLogin: true, userTokenId: nextProps.userTokenId, userInfo: nextProps.userInfo, onAsync: false }, () => {
            });
        }
        if (nextProps.loginErrorMsg != '') {
            this.setState({ loginErrorPopup: true });
        }
        if (nextProps.passwordUpdateMsg != '') {
            this.setState({ visibleAlert: true });
        }
        if (nextProps.usermsg !== "") {
            this.setState({ visibleAlert: true });
        }
    }
    handleEnterKey = (e) => {
        if (e.key === 'Enter') {
            this.loginSubmit();
        }
    }
    loginSubmit() {
        this.setState({ isUserLogin: false, userTokenId: '' });
        if (this.validateAll()) {
            this.setState({ onAsync: true })
            let formData = this.state.fields;

            this.props.loginUser(formData, true, true);
            this.setState({ onAsync: false })
        } else {
            console.log("Form has errors.");
        }
    }
    toggleLoginErrorModal() {
        this.setState({ loginErrorPopup: false });
    }
    onDismissAlert() {
        this.setState({ visibleAlert: !this.state.visibleAlert })
    }
    handleClickShowPassword() {
        this.setState({ showPassword: !this.state.showPassword });
    }
    render() {
        const { errors } = this.state
        const { authLoading, passwordUpdateMsg, usermsg } = this.props
        const { userTokenId, isUserLogin, userInfo, visibleAlert, showPassword } = this.state;

        console.log("usermsg====", usermsg);

        if (isUserLogin == true && userTokenId != '' && userInfo && userInfo.partnerid != '' && userInfo.partnerid != undefined) {
            return (<Redirect to="/partner/dashboard" />)
        }
        return (
            <>
                {/* <div>
                    <Header />
                </div> */}
                <div className="avibra_agents_reg_form avibra_partner_dashboard h-100">
                    {/* <ToastContainer /> */}
                    {<Row className="h-100">
                        <Col xs="12" md="12" lg="6" className="right-side">
                            <div className="right__logo">
                                <img src={require("./../../../images/avibraLoginLogo.svg")}></img>
                            </div>
                            {/* <h2 className="agents-signup-heading" style={{ paddingTop: '25px', marginTop: '25px' }}>Login</h2> */}
                        </Col>
                        <Col xs="12" md="12" lg="6">
                            <div className="d-flex align-items-center">
                                <div className="header_form">
                                    <div className="login-link btn">
                                        <Link to="/partner/signup">
                                            <div>Create New Account</div>
                                        </Link>
                                    </div>
                                    <div className="submit-login-devider">
                                        <span>OR</span>
                                    </div>
                                    <div className="text__login">
                                        Login
                                    </div>
                                    <div className="form_fields_list" data-recording-ignore="mask">


                                        <Row>
                                        </Row>
                                        {/* <div className="form_field_item"> */}
                                        <CommonInput placeholder="Email" name='email' type="text" autocomplete="off" error={this.state.errors["email"]}
                                            onChange={this.handleChange.bind(this, "email")} value={this.state.fields["email"]} className={"common-input"} />
                                        {/* <span className="error_msg">{this.state.errors["email"]}</span>
                                    </div> */}
                                        {/* <div className="form_field_item password">
                                        <div className="password-field"> */}
                                        <CommonInput
                                            placeholder="Password"
                                            name='password'
                                            type="password"
                                            autocomplete="off"
                                            type={showPassword ? 'text' : 'password'}
                                            onChange={this.handleChange.bind(this, "password")}
                                            value={this.state.fields["password"]}
                                            outerClass={"password"}
                                            className={"common-input"}
                                            passwordClass={"password-field"}
                                            handleClickShowPassword={this.handleClickShowPassword.bind(this)}
                                            showPassword={showPassword}
                                            error={this.state.errors["password"]}
                                        />
                                        {/* <span onClick={() => this.handleClickShowPassword()}>{showPassword ? <i className="fa fa-eye" aria-hidden="true"></i> : <i className="fa fa-eye-slash" aria-hidden="true"></i>}</span>
                                        </div>
                                        <span className="error_msg">{this.state.errors["password"]}</span>
                                    </div> */}


                                        <Button
                                            className="header_submit_btn"
                                            type="submit" onClick={this.loginSubmit}
                                        >
                                            {
                                                authLoading ?
                                                    <ReactLoading
                                                        type={'spin'}
                                                        color={'white'}
                                                        height={20}
                                                        width={20}
                                                        style={{ width: '20px', height: '20px', color: 'white', textAlign: 'center', margin: '0 auto' }}
                                                    />
                                                    : 'Log in'
                                            }
                                        </Button>
                                        {/* <div>
                                        <Button disabled={this.state.onAsync} className="header_submit_btn" onClick={() => this.signupSubmit()}>
                                            {!isSubmitLoading ? (
                                                "Submit"
                                            ) : (
                                                <i className="fas fa-circle-notch fa-spin"></i>
                                            )}</Button>
                                    </div> */}
                                    </div>

                                    {this.state.errors["login"] ? <Alert color="danger" style={{ marginTop: "5%" }} isOpen={visibleAlert} toggle={() => { this.onDismissAlert() }}>{this.state.errors["login"]}</Alert> : null}
                                    {this.props.loginErrorMsg && this.state.loginErrorPopup && <PopUpModal isOpen={this.state.loginErrorPopup} toggleModal={() => this.toggleLoginErrorModal()} heading={"Error"} description={this.props.loginErrorMsg} />}
                                    {passwordUpdateMsg !== '' ? <Alert color="success" style={{ marginTop: "5%" }} isOpen={visibleAlert} toggle={() => { this.onDismissAlert() }}>{passwordUpdateMsg}</Alert> : null}
                                    {usermsg ? <Alert color="danger" style={{ marginTop: "5%" }} isOpen={visibleAlert} toggle={() => { this.onDismissAlert() }}>{usermsg}</Alert> : null}

                                    {/* <span className="error_msg">{this.state.errors["login"]}</span> */}
                                </div>
                            </div>
                        </Col>
                        {this.state.showCropImageModal && this.state.selectedImage && <CropImageModal isOpen={this.state.showCropImageModal} toggleModal={(cropImage) => this.toggleCropImageModal(cropImage)} heading={"Edit Image"} selectedImage={selectedImage} />}
                    </Row>}
                </div>
            </>


        )
    }
}
const mapStateToProps = state => {
    const { userTokenId, isUserLogin, userInfo, authLoading, loginErrorMsg, passwordUpdateMsg, usermsg } = state.authReducer;
    return { userTokenId, isUserLogin, userInfo, authLoading, loginErrorMsg, passwordUpdateMsg, usermsg };
}

export default connect(mapStateToProps, { authenticateUser, loginUser, resetAgentData })(PartnerDashboardLogin);


