import React, { Component } from 'react'
import { Switch, Link } from 'react-router-dom'
import { PrivateRoute } from '../../components/PrivateRoute';
import { Redirect } from 'react-router';

import Header from './Header'
import DashboardHome from './Routes/DashboardHome'
import PartnerUserList from './Routes/PartnerUserList';
import Profile from './Routes/Profile'
import UpdatePassword from './Routes/UpdatePassword'
import SaleSummary from './Routes/SaleSummary'
import ClientCommunication from './Routes/ClientCommunication'
import Campaign from './Routes/Campaign';

import { connect } from 'react-redux'

import { getPartnerDetail } from '../../actions/partnerDashboardAction';
import { CheckIsUserLoggedIn, SignOut } from '../../actions/authAction';

import "../../../styles/Agents/Dashboard/Dashboard.css"
import "../../../styles/Agents/Dashboard/Dashboardresponsive.css"
import "../../../styles/Agents/Grid/col.css"
import Icon from '@material-ui/core/Icon';
import { isEqual } from 'lodash';

var sidebarLinks = [
    {
        label: "Overview",
        link: "",
        icon: "dashboard"
    },
    {
        label: "Member Dashboard",
        link: "memberdashboard",
        icon: "groups"
    },
    {
        label: "Lead Summary",
        link: "leadsummary",
        icon: "insights"
    },
    // {
    //     label: "Client Communication",
    //     link: "clientcommunication",
    //     icon: "mail"
    // },
    {
        label: "Classifiers",
        link: "campaign",
        icon: "list_alt"
    }
]
class PartnerDashboard extends Component {
    constructor(props) {
        super(props)
        this.state = {
            isShow: false,
            dropdownOpen: false,
            isUserLogin: true,
        }
    }
    componentDidMount() {
        // const userInfo = JSON.parse(localStorage.getItem('userInfo'));
        console.log('this.props.userInfo====', this.props.userInfo);

        const userTokenId = localStorage.getItem('userTokenId')
        const { partnerid = "" } = this.props.userInfo;

        if (this.props.userInfo && partnerid && userTokenId) {
            this.props.getPartnerDetail(partnerid)
        } else {
            this.setState({ isUserLogin: false })
        }
    }

    UNSAFE_componentWillReceiveProps(nextProps) {

        const userTokenId = localStorage.getItem('userTokenId')

        if (!isEqual(this.props.userInfo, nextProps.userInfo) && nextProps.userInfo.partnerid && userTokenId) {
            this.setState({ isUserLogin: true })
            this.props.getPartnerDetail(nextProps.userInfo.partnerid)
        }

    }
    signOutUser() {
        this.props.SignOut();
    }

    onClickSidebar = () => {
        this.setState({
            isShow: !this.state.isShow,
        })
    }

    hideSidebar = () => {
        this.setState({
            isShow: !this.state.isShow
        });
    }
    closeSidebarLink = () => {
        this.setState({
            isShow: false,
        })
    }
    toggle = () => {
        this.setState({
            dropdownOpen: !this.state.dropdownOpen
        });
    }

    render() {
        const { match = {} } = this.props;
        const { isUserLogin } = this.state;
        const { userTokenId } = this.props;
        
        if (userTokenId == null && isUserLogin == false) {
            return (<Redirect to="/partner/login" />)
        }
        return (
            <div className="container-fluid dashboard_page p-0">
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" />

                <Header menuLinks={sidebarLinks} menuPath={this.props.location.pathname} />
                <div className="clearfix"></div>
                <div className="container-flued">
                    <div className="row">
                        <nav className="col-md-2 d-none d-md-block bg-light dashboard-sidebar">
                            <div className="sidebar-sticky">
                                <ul className="nav flex-column">
                                    {
                                        sidebarLinks.map((item, index) => {
                                            return (
                                                <li key={`${index}_li`} className={(this.props.location.pathname == `/partner/dashboard/${item.link}`) ? 'nav-item active' : 'nav-item'}  >
                                                    <Link className="nav-link" to={`/partner/dashboard/${item.link}`}>
                                                        <Icon>{item.icon}</Icon>
                                                        {item.label}
                                                    </Link>
                                                </li>
                                            )
                                        })
                                    }
                                </ul>
                            </div>
                        </nav>

                        <main role="main" className="col-md-10 ml-sm-auto col-lg-10">
                            <Switch>
                                <PrivateRoute exact path={`${match.path}`} redirectPath={'/partner/login'} component={DashboardHome} />
                                <PrivateRoute exact path={`${match.path}/memberdashboard`} redirectPath={'/partner/login'} component={PartnerUserList} />
                                {/* <PrivateRoute exact path={`${match.path}/updatelogo`} redirectPath={'/partner/login'} component={UpdateLogo} /> */}
                                <PrivateRoute exact path={`${match.path}/profile`} redirectPath={'/partner/login'} component={Profile} />
                                <PrivateRoute exact path={`${match.path}/updatepassword`} redirectPath={'/partner/login'} component={UpdatePassword} />
                                <PrivateRoute exact path={`${match.path}/leadsummary`} redirectPath={'/partner/login'} component={SaleSummary} />
                                <PrivateRoute exact path={`${match.path}/clientcommunication`} redirectPath={'/partner/login'} component={ClientCommunication} />
                                <PrivateRoute exact path={`${match.path}/campaign`} redirectPath={'/partner/login'} component={Campaign} />
                            </Switch>

                        </main>
                    </div>
                </div>
            </div>)
    }
}
const mapStateToProps = state => {
    const { loginResult, authData, userInfo, userTokenId, isUserLogin } = state.authReducer;
    const { agentData } = state.agentReducer;
    const { partnerData } = state.partnerDashboardReducer;

    return { loginResult, authData, userInfo, agentData, userTokenId, isUserLogin, partnerData };
}

export default connect(mapStateToProps, { getPartnerDetail, SignOut, CheckIsUserLoggedIn })(PartnerDashboard);


