import React, { useEffect } from 'react'
import { Switch, Route } from "react-router-dom"
import { PrivateRoute } from '../../components/PrivateRoute';
import PartnerDashboardPage from "../../views/PartnerDashboardPage/PartnerDashboardPage"
import PartnerDashboardRegistrationPage from "../../views/PartnerDashboardPage/PartnerDashboardRegistrationPage"
import PartnerDashboardLogin from "../../views/PartnerDashboardPage/PartnerDashboardLogin"
import PartnerDashboard from "../../views/PartnerDashboardPage/PartnerDashboard"
import { CheckIsUserLoggedIn } from '../../actions/authAction';
import store from '../../store/store';

const PartnerDashboardContainer = () => {

    useEffect(() => {
        store.dispatch(CheckIsUserLoggedIn())
    }, [])

    return <Switch>
        <Route exact path="/" component={PartnerDashboardPage} />
        {/* <Route path="/partner/signup/:agencyname" component={PartnerDashboardRegistrationPage} /> */}
        <Route path="/partner/signup" component={PartnerDashboardRegistrationPage} />
        <Route path="/partner/login" component={PartnerDashboardLogin} />
        <PrivateRoute path="/partner/dashboard" redirectPath={'/partner/login'} component={PartnerDashboard} />
        {/* <Route exact path="/:agencyname" component={PartnerDashboardPage} /> */}
    </Switch>
}

export default PartnerDashboardContainer
