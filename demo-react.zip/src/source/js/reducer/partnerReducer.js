import { PARTNER_CAMPAIGN_COUNT, RESET_PARTNER_DASH_DATA, UPDATE_STATUS, SET_PARTNER_DASH_DATA, SET_PARTNER_LOGO, PARTNER_USER_SEARCH_DATA, PARTNER_CAMPAIGN_USER_DETAIL, PARTNER_USER_COUNT, PARTNER_USER_FILTER_DATA, PARTNER_CLASSIFIERS, CHART_DATA, PARTNER_CAMPAIGN_LIST, PARTNER_CAMPAIGN_SUMMARY_LIST, PARTNER_CAMPAIGN_USER_LIST, PARTNER_CAMPAIGNS } from "../types";

const INITIAL_STATE = {
    partnerCampagnList: [],
    summaryList: [],
    userList: [],
    campaigns: [],
    charts: {},
    classifiers: {},
    partnerUserCount: 0,
    partnerFilterData: {},
    partnerUserDetail: {},
    partnerSearchData: false,
    partnerData: {},
    partnerLogo: null,
    updateProfileStatus: null,
    partnerCampCount: 0,
}

export default (state = INITIAL_STATE, action) => {
    switch (action.type) {
        case PARTNER_CAMPAIGN_LIST:
            return { ...state, partnerCampagnList: action.payload }
        case PARTNER_CAMPAIGN_SUMMARY_LIST:
            return { ...state, summaryList: action.payload }
        case PARTNER_CAMPAIGN_USER_LIST:
            return { ...state, userList: action.payload }
        case PARTNER_CAMPAIGNS:
            return { ...state, campaigns: action.payload }
        case CHART_DATA:
            return { ...state, charts: action.payload }
        case PARTNER_CLASSIFIERS:
            return { ...state, classifiers: action.payload }
        case PARTNER_USER_COUNT:
            return { ...state, partnerUserCount: action.payload }
        case PARTNER_USER_FILTER_DATA:
            return { ...state, partnerFilterData: action.payload }
        case PARTNER_CAMPAIGN_USER_DETAIL:
            return { ...state, partnerUserDetail: action.payload }
        case PARTNER_USER_SEARCH_DATA:
            return { ...state, partnerSearchData: action.payload }
        case SET_PARTNER_DASH_DATA:
            return { ...state, partnerData: action.payload }
        case SET_PARTNER_LOGO:
            return { ...state, partnerLogo: action.payload }
        case UPDATE_STATUS:
            return { ...state, updateProfileStatus: action.payload }
        case RESET_PARTNER_DASH_DATA:
            return INITIAL_STATE;
        case PARTNER_CAMPAIGN_COUNT:
            return { ...state, partnerCampCount: action.payload }
        default:
            return state;
    }
}