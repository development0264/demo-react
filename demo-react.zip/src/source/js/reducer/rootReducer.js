import { combineReducers } from 'redux';
import partnerReducer from './partnerReducer';

const allReducers = combineReducers({
    partnerReducer,
});

export default allReducers