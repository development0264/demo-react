import { apiPost } from "../utils/api"

import { API_URL } from "../../constant/constant"

export const postPartner = (requestUrl, data, headers = {}) => apiPost(`${API_URL}${requestUrl}`, data, headers);