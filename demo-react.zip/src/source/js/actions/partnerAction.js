import { SET_PARTNER_DASH_DATA, SET_PARTNER_LOGO, } from "../types";
import axios from 'axios';

export const getPartnerDetail = (partnerid) => {
    return (dispatch) => {
        axios.get(`/profiles/partner/${partnerid}`).then((response) => {
            //dispatch(CheckUserLogin());
            if (response.data.length) {
                dispatch({ type: SET_PARTNER_DASH_DATA, payload: response.data[0] });
                dispatch({ type: SET_PARTNER_LOGO, payload: response.data[0] ? response.data[0].logourl : '' });
            }
        }).catch(err => {
            console.log("getAgentDetail Error", err);
        })
    }
}